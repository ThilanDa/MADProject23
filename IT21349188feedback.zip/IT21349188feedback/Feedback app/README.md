# Feedback Android Application
## College Feedback Android Application using Firebase as backend

### If you want to use this project, replace the google-services.json file with yours! Hurray, that will be work for you!

Screenshots

![alt text](https://i.postimg.cc/1tRVNQDG/1.png "Screenshot 1")

![2.png](https://i.postimg.cc/3RL4XcZP/2.png "Screenshot 2")




